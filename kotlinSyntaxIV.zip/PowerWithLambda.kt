package jusanSingularity.kotlinSyntaxIV

fun main() {
    2.power(10){ println(it) }
}

/*
Задача 2
Необходимо создать Extention function для Int, которая возводит в заданную степень число.
Результат будет передан в лямбду, которую данный метод принимает как аргумент.
На вход (аргументы) метод принимает степень (Int) и лямбду, которая возвращает Unit.
*/

fun Int.power(n: Int, lambda:(Int)-> Unit) {
    if (n == 0 || this == 1) {
        lambda(1)
    }
    if (this == 0) {
        lambda(0)
    }

    var result = 1

    for (i in 0 until n) {
        result *= this
    }

    lambda(result)
}