package jusanSingularity.kotlinSyntaxIV

fun main() {
    println(2.power(3))
}

/*
Задача 1
Необходимо создать Extention function для Int, которая возводит в определенную степень число и возвращает результат.
На вход (аргументы) принимает только нужную степень (Int).
*/

fun Int.power(n: Int): Int {
    if (n == 0 || this == 1) {
        return 1
    }
    if (this == 0) {
        return 0
    }

    var result = 1

    for (i in 0 until n) {
        result *= this
    }

    return result
}