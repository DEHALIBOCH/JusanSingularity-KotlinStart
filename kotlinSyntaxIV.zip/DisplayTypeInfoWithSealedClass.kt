package jusanSingularity.kotlinSyntaxIV

fun main() {
    3.displayTypeInfo()
    "a".displayTypeInfo()
    true.displayTypeInfo()
    DataType.DoubleType(1.4).displayTypeInfo()
    DataType.UnitType().displayTypeInfo()
}

/*
Задача 4 (*)
Необходимо модифицировать метод displayTypeInfo, добавив в него новый тип DataType.

DataType - это новый sealed class, у которого есть 2 наследника - DoubleType и UnitType.
У DoubleType есть поле:
    value : Double

Необходимо определить extension метод для DataType, который выводит информацию о подтипах этого класса:
    Для DoubleType будет выводится это DoubleType со значением {значение}
    Для UnitType будет выводится это Unit

Итого, должно быть реализовано:
    Метод displayTypeInfo для generic типов
    displayDataTypeInfo extension метод для DataType
    sealed class DataType
 */

sealed class DataType {
    class DoubleType(val value: Double)
    class UnitType
}

fun <T> T.displayTypeInfo(): Unit {
    when (this) {
        is Int -> println("это Int")
        is String -> println("это String")
        is DataType.DoubleType -> println("это DoubleType со значением ${this.value}")
        is DataType.UnitType -> println("это Unit")
        else -> println("тип у $this неизвестен")
    }
}