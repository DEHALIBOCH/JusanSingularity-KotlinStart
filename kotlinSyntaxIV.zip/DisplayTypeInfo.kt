package jusanSingularity.kotlinSyntaxIV

fun main() {
    3.displayTypeInfo()
    "a".displayTypeInfo()
    true.displayTypeInfo()
}

/*
Задача 3
Необходимо написать Extention function для generic типа, которая выводит информацию о generiс типе.
Назвать метод displayTypeInfo.
Если функция вызвана для String, то метод выводит "это String", если вызывается для Int, то выводится "это Int",
а для остальных типов будет выводиться сообщение "тип у {заданное значение} неизвестен".
 */

//fun <T> T.displayTypeInfo(): Unit {
//    when (this) {
//        is Int -> println("это Int")
//        is String -> println("это String")
//        else -> println("тип у $this неизвестен")
//    }
//}