package jusanSingularity.kotlinSyntaxIII

import kotlin.math.pow
import kotlin.math.sqrt

class Point(var x: Int = 0, var y: Int = 0) {

    fun distanceBetweenPoints(b: Point): Double {
        return sqrt((this.x - b.x + 0.0).pow(2.0) + (this.y - b.y + 0.0).pow(2.0))
    }

    override fun toString(): String {
        return "[$x;$y]"
    }

    fun collinearity(b: Point): Boolean {
        val x = this.x * 1.0 / b.x
        val y = this.x * 1.0 / b.x
        return x == y
    }
}

