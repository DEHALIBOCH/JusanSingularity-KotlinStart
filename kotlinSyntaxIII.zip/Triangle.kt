package jusanSingularity.kotlinSyntaxIII

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class Triangle {

    var a: Point
    var b: Point
    var c: Point

    constructor() {
        this.a = Point(-1, 0)
        this.b = Point(0, 1)
        this.c = Point(1, 1)
    }

    constructor(a: Point, b: Point, c: Point) : this() {
        if (a.collinearity(b) && b.collinearity(c)) {
            this.a = Point(-1, 0)
            this.b = Point(0, 1)
            this.c = Point(1, 1)
        } else {
            this.a = a
            this.b = b
            this.c = c
        }
    }


    fun setA(p: Point) {
        if (!(this.b.collinearity(p) && this.c.collinearity(p))) {
            this.a = p
        } else {
            println("Invalid point")
        }
    }

    fun setB(p: Point) {
        if (!(this.a.collinearity(p) && this.c.collinearity(p))) {
            this.b = p
        } else {
            println("Invalid point")
        }
    }

    fun setC(p: Point) {
        if (!(this.a.collinearity(p) && this.b.collinearity(p))) {
            this.c = p
        } else {
            println("Invalid point")
        }
    }

    fun print() {
        println("Triangle(a = $a, b = $b, c = $c)")
    }

    fun getPerimeter(): Double {
        val ab = a.distanceBetweenPoints(b)
        val bc = b.distanceBetweenPoints(c)
        val ac = c.distanceBetweenPoints(a)
        return ab + bc + ac
    }

    fun getSquare(): Double {
        val ab = a.distanceBetweenPoints(b)
        val bc = b.distanceBetweenPoints(c)
        val ac = c.distanceBetweenPoints(a)
        val p = (ab + bc + ac) / 2

        return sqrt(p * (p - ab) * (p - bc) * (p - ac))
    }

    fun rotate(d: Double) {
        val rad = d * PI / 180
        val cos = cos(rad)
        val sin = sin(rad)

        val ax = a.x * cos - a.x * sin
        val ay = -a.x * cos + a.x * sin
        val bx = b.x * cos - b.x * sin
        val by = -b.x * cos + b.x * sin
        val cx = c.x * cos - c.x * sin
        val cy = -c.x * cos + c.x * sin

        a = Point(ax.toInt(), ay.toInt())
        b = Point(bx.toInt(), by.toInt())
        c = Point(cx.toInt(), cy.toInt())
    }
}


/*
Задача 1.
Создайте класс треугольников на координатной плоскости, используя в качестве полей объекты-точки.
Реализуйте в классе:
    a) параметр, позволяющий задавать вершины с вручную;
    b) метод print() выводящий описание треугольника на экран;
    c) методы для вычисления периметра и площади треугольника.

Задача 2.
Доработайте конструктор таким образом, чтобы нельзя было задать три вершины, лежащие на одной прямой.
Это несложно будет сделать с использованием метода из класса точек, который проверяет, являются ли точки коллинеарными,
если прежде вы не реализовали этот метод, то сейчас самое время сделать это.

Задача 3.
Инкапсулируйте поля таким образом, чтобы нельзя изменить значение любого из них так,
чтобы вершины оказались на одной прямой.

Задача 4. Со звездочкой.
Создайте метод, поворачивающий треугольник вокруг центра тяжести на указанное в аргументе количество градусов.
 */